void findAll(char g_arrWebSite[300][20], char g_arrUserName[300][20], char g_arrPassWord[300][20], int* nCount);
void findInfoBySite(char g_arrWebSite[300][20], char g_arrUserName[300][20], char g_arrPassWord[300][20], int* nCount);
void addInfo(char g_arrWebSite[300][20], char g_arrUserName[300][20], char g_arrPassWord[300][20], int* nCount);
void upDateInfoBySite(char g_arrWebSite[300][20], char g_arrUserName[300][20], char g_arrPassWord[300][20], int* nCount);
void deleteInfoBySite(char g_arrWebSite[300][20], char g_arrUserName[300][20], char g_arrPassWord[300][20], int* nCount);