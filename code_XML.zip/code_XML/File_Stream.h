void ReadMimaInfo(char WebSite[300][20], char User[300][20], char Mima[300][20], int* pCount);
void SaveFile(char WebSite[300][20], char User[300][20], char Mima[300][20], int* pCount);